import heapq
import numpy
import csv
import os

#-------------------------------------------------------------------#
class SquareGrid:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [] #Array of coordinates containing walls
    
    #check if coordinates are within the bounds of the map    
    def in_bounds(self, id):
        (x, y) = id
        return 0 <= x < self.width and 0 <= y < self.height
    
    #return true if there is no wall at the coordinates
    def passable(self, id):
        return id not in self.walls
    
    #returns the neighboring cells that can be traversed from current location
    def neighbors(self, id):
        (x, y) = id
        #limit neighbors to up/down/left/right
        results = [(x+1, y), (x, y-1), (x-1, y), (x, y+1)]
        if (x + y) % 2 == 0: results.reverse() # aesthetics
        results = filter(self.in_bounds, results)
        results = filter(self.passable, results)
        return results

#-------------------------------------------------------------------#
#Implement a priority queue using the python heap queue library
class PriorityQueue:
    def __init__(self):
        self.elements = []
    
    def empty(self):
        return len(self.elements) == 0
    
    def put(self, item, priority):
        heapq.heappush(self.elements, (priority, item))
    
    def get(self):
        return heapq.heappop(self.elements)[1]
        
#-------------------------------------------------------------------#
#read a csv file and convert to a numpy array
def readMap(fileName):
    reader = csv.reader(open(fileName, "rU"), delimiter=",")
    x = list(reader)
    return numpy.array(x).astype(int)

#-------------------------------------------------------------------#
#use the Manhattan heuristic for A* Search
def heuristic(a, b):
    (x1, y1) = a
    (x2, y2) = b
    return abs(x1 - x2) + abs(y1 - y2)
    
#-------------------------------------------------------------------#   
#A* Search algorithm
def a_star_search(graph, start, goal):
    frontier = PriorityQueue()
    frontier.put(start, 0) # Each node has a location and a priority
    came_from = {}
    cost_so_far = {}
    came_from[start] = None #Root node
    cost_so_far[start] = 0  #Root node
    
    #While there is still nodes unexplored:
    while not frontier.empty():
        current = frontier.get()
        
        #Stop if goal is reached
        if current == goal:
            break
        
        #Look at the next position and add one to the total cost
        for next in graph.neighbors(current):
            new_cost = cost_so_far[current] + 1
            #Check next node which has not been checked
            if next not in cost_so_far or new_cost < cost_so_far[next]:
                cost_so_far[next] = new_cost
                #Calculate new priority given the cost and heuristic                
                priority = new_cost + heuristic(goal, next)
                frontier.put(next, priority)
                came_from[next] = current #Itterate
    
    #Return the dictionary of coordinates with their corresponding parent node    
    return came_from, cost_so_far

#-------------------------------------------------------------------#
#Take the completed dictionary from A* and filter the nodes in the path to goal
def reconstruct_path(came_from, start, goal):
    current = goal
    path = [current]
    while current != start:
        current = came_from[current]
        path.append(current)
    path.append(start) # optional
    path.reverse() # optional
    return path   
    
#-------------------------------------------------------------------#
#-------------------------------MAIN--------------------------------#
#-------------------------------------------------------------------#

#Load the world file into a numpy array
dirPath = os.path.dirname(os.path.realpath(__file__))
filePath = dirPath + "/world.csv"
worldArray = readMap(filePath)

#Determine the size of the world
(worldHeight, worldWidth) = worldArray.shape

#Initialize the world grid
world = SquareGrid(worldWidth, worldHeight)

#Loop through the worldArray looking for walls
for (x,y), value in numpy.ndenumerate(worldArray):
    if worldArray[x,y] == 1:
        world.walls.append((x,y))

#Set the coordinates of the starting place and end goal        
start = (0,0)
goal = (worldHeight-1, worldWidth-1)

#Implement the A* search Algorithm
came_from, cost_so_far = a_star_search(world, start, goal)

#connect the path nodes together
path = reconstruct_path(came_from, start, goal)

#show the values in worldArray
for (x,y), value in numpy.ndenumerate(worldArray):
    if (x,y) in path:
        worldArray[x,y] = 2